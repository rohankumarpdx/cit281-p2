/*
    CIT 281 Project 2
    Name: Rohan Kumar
*/

// Returns a random number between min (inclusive) and max (exclusive)
const getRandomInteger = function(min, max) 
{
    return Math.floor(Math.random() * (max - min) + min);
}

const alphabet = "abcdefghijklmnopqrstuvwxyz".split("");
let result = "";

for (let i = 0; i < getRandomInteger(5, 26); i++) 
{
    result += alphabet[getRandomInteger(1,alphabet.length-1)];
}

console.log(result);

//getRandomLetter - prints single random lowercase letter
const getRandomLetter = function()
{
    const alphabet = 'abcdefghijklmnopqrstuvwxyz';
    return alphabet[Math.floor(Math.random() * alphabet.length)];
}

console.log(getRandomLetter);

const getRandomString = function(minLength, maxLength) 
{

    //Initialize empty base string
    let base = "";
    const charactersLength = availableChars.length;
    //Loop through string and add a random letter until specified random length has been reached
    for (let i = minLength; i < maxLength; i++)
    {
        base += availableChars.charAt(Math.floor(Math.random() * charactersLength));
    }
    return base;
}
console.log(getRandomString(10, 20));


//take an inputted string and reverse its characters
const getSortedString = function(string)
{
    return string.split("").reverse().join("");
}
console.log(getSortedString("Hello!"));